drop database if exists travel;
create database travel;
USE travel;

drop table if exists destinations;
create table destinations(
destinations_id INT PRIMARY KEY,
city_name VARCHAR (100),
state_name VARCHAR (100)
);

insert into destinations(destinations_id, city_name, state_name) values (1, 'New York', 'New York');
insert into destinations(destinations_id, city_name, state_name) values (2, 'San Diego', 'California');
insert into destinations(destinations_id, city_name, state_name) values (3, 'Honolulu', 'Hawaii');
insert into destinations(destinations_id, city_name, state_name) values (4, 'Estes Park', 'Colorado');
insert into destinations(destinations_id, city_name, state_name) values (5, 'Seattle', 'Washington');

drop table if exists hotels;
create table hotels(
hotels_id INT PRIMARY KEY,
hotel_name VARCHAR (100),
rating INT not null
);

insert into hotels(hotels_id, hotel_name, rating) values (1, 'Hilton Times Square', 4.5);
insert into hotels(hotels_id, hotel_name, rating) values (2, 'Manchester Grand Hyatt', 4);
insert into hotels(hotels_id, hotel_name, rating) values (3, 'Hilton Waikiki Beach', 4);
insert into hotels(hotels_id, hotel_name, rating) values (4, 'The Maxwell Inn', 3);
insert into hotels(hotels_id, hotel_name, rating) values (5, 'Fairmont Olympic Hotel', 5);

drop table if exists price;
create table price(
price_id INT PRIMARY KEY,
price INT not null
);

insert into price(price_id, price) values (1, 1676);
insert into price(price_id, price) values (2, 1094);
insert into price(price_id, price) values (3, 1373);
insert into price(price_id, price) values (4, 1386);
insert into price(price_id, price) values (5, 1092);

SELECT * FROM destinations;

SELECT * FROM hotels
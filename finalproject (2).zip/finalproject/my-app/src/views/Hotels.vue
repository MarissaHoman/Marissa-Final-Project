<template>
    <div>
            <span>{{hotels.hotelName}}</span>

            <ul>
                <li>{{hotels.hotelName}}</li>
                <li>{{hotels.rating}}</li>
            </ul>
    </div>
</template>
<script>
export default {
    data: () => ({
        hotels: null
    }),
    async mounted(){
        const { data } = await this.$http.get('http://localhost:8080/api/hotels/' + this.$route.params.id);
        this.hotels = data;
    }
}
</script>
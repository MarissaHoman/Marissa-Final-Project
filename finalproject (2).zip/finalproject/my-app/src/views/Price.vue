<template>
    <div>
            <span>{{price.price}}</span>

            <ul>
                <li>{{hotels.price}}</li>
            </ul>
    </div>
</template>
<script>
export default {
    data: () => ({
        price: null
    }),
    async mounted(){
        const { data } = await this.$http.get('http://localhost:8080/api/price/' + this.$route.params.id);
        this.price = data;
    }
}
</script>
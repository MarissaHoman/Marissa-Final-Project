<template>
  <div class="row">
    <h1>COVID Hotspots</h1>
    <p>
      To check for current COVID Hotspots, please click link!
      <a href="https://public.tableau.com/views/UnitedStatesCOVID-19Dashboard_16135277453270/PrimaryDashboard?:language=en&:display_count=y&:origin=viz_share_link" target="_blank" rel="noopener">COVID Hotspots</a>.
    </p>
</template>
<template>
    <div>
        <h1 class="title">Add Destinations</h1>
      
        
        <div class="field">
            <label class="label">City</label>
            <div class="control">
                <input class="input" type="text" v-model="destinations.cityName" placeholder="City Name"/>
            </div>
        </div>

        <div class="field">
            <label class="label">State</label>
            <div class="control">
                <input class="input" type="text" v-model="destinations.stateName" placeholder="State Name"/>
            </div>
        </div>

        <div class="field is-grouped">
            <p class="control">
                <button v-on:click="cancel" class="button">Cancel</button>
            </p>

            <p class="control">
                <button v-on:click="save" class="button is-primary">Save</button>
            </p>
        </div>
        
    </div>
</template>

<script>
export default {
    name: 'AddDestinations',
    data: () => ({
        destinations: {
            cityName: "",
            stateName: ""
        }
    }),
    methods:{
        cancel(){
            this.$router.push({path: '/destinations'});
        },
        async save(){
            const response = await this.$http.post('http://localhost:8080/api/destinations/',
            this.actor)
            console.log(response);
            if( response.status === 200){
                this.$router.push({path: '/destinations'});
            }
        }
    }
}
</script>
package com.finalproject.finalproject.entity.Destinations.Hotels.Price;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/api")
public class PriceController {

    @Autowired
    private PriceRepository priceRepository;

    @GetMapping(path = "/price")
    public Iterable<Price> getAllPrice() {
        return priceRepository.findAll();
    }

    @GetMapping(path = "/{id}")
    public Price getPrice(@PathVariable(value = "id") Integer id) {
        Optional<Price> price = priceRepository.findById(id);
        return price.get();
    }

    @PostMapping(path = "/price")
    public Price createPrice(@RequestBody Price price) {
        return priceRepository.save(price);
    }

}

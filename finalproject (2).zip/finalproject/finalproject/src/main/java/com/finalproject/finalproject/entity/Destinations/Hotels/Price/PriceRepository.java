package com.finalproject.finalproject.entity.Destinations.Hotels.Price;


import org.springframework.data.repository.CrudRepository;

public interface PriceRepository extends CrudRepository<Price, Integer> {
    
}

package com.finalproject.finalproject.entity.Destinations;

import org.springframework.data.repository.CrudRepository;

public interface DestinationsRepository extends CrudRepository<Destinations, Integer> {
    
}

package com.finalproject.finalproject.entity.Destinations.Hotels;

import org.springframework.data.repository.CrudRepository;

public interface HotelsRepository extends CrudRepository<Hotels, Integer> {
    
}
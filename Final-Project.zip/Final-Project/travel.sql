drop database if exists travel;
create database travel;

drop table if exists destinations;
create table destinations(
destinations_id INT PRIMARY KEY,
city_name VARCHAR (100),
state_name VARCHAR (100)
);

insert into destinations(city_name, state_name) values ('New York', 'New York');
insert into destinations(city_name, state_name) values ('San Diego', 'California');
insert into desintations(city_name, state_name) values ('Honolulu', 'Hawaii');
insert into destinations(city_name, state_name) values ('Estes Park', 'Colorado');
insert into destinations(city_name, state_name) values ('Seattle', 'Washington');

drop table if exists hotels;
create table hotels(
hotels_id INT PRIMARY KEY,
hotel_name VARCHAR (100),
rating INT not null
);

insert into hotels(hotel_name, rating) values ('Hilton Times Square', 4.5);
insert into hotels(hotel_name, rating) values ('Manchester Grand Hyatt', 4);
insert into hotels(hotel_name, rating) values ('Hilton Waikiki Beach', 4);
insert into hotels(hotel_name, rating) values ('The Maxwell Inn', 3);
insert into hotels(hotel_name, rating) values ('Fairmont Olympic Hotel', 5);

drop table if exists price;
create table price(
price_id INT PRIMARY KEY,
price INT not null
);

insert into price(price) values (1676);
insert into price(price) values (1094);
insert into price(price) values (1373);
insert into price(price) values (1386);
insert into price(price) values (1092);

